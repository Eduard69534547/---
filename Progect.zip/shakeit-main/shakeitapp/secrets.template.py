# Переименуйте этот файл в secrets.py впишите в соответствующие строки
# токены доступа к Fusionbrain (Kandinsky от Сбер)
KANDINSKY_SECRET_TOKEN = ''
KANDINSKY_API_TOKEN = ''
