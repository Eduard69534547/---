from django.apps import AppConfig


class ShakeitappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shakeitapp'
    verbose_name = 'Сайт ShakeIt.su'
