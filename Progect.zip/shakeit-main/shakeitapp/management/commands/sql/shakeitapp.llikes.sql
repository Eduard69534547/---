INSERT INTO shakeitapp_llikes
(id, ll_is_like, ll_cocktail_id, ll_user_id)
VALUES(1, 1, 1, 1);
