INSERT INTO shakeitapp_dunits (du_name,du_anno) VALUES
	 ('мл','миллилитр'),
	 ('г','грамм'),
	 ('шт','штука');
