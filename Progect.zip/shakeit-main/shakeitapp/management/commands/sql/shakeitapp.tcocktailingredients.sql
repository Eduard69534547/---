INSERT INTO shakeitapp_tcocktailingredients (ci_quantity,ci_cocktail_id,ci_ingredient_id,ci_unit_id) VALUES
	 ('120',1,1,1),
	 ('400',1,2,1),
	 ('240',1,3,2),
	 ('10',1,4,3),
	 ('450',1,5,2),
	 ('10',2,1,1),
	 ('15',2,6,1),
	 ('100',2,7,1),
	 ('150',2,8,2),
	 ('350',2,5,2);
INSERT INTO shakeitapp_tcocktailingredients (ci_quantity,ci_cocktail_id,ci_ingredient_id,ci_unit_id) VALUES
	 ('50',3,9,1),
	 ('250',3,10,1),
	 ('500',3,2,1),
	 ('200',3,11,2),
	 ('60',3,12,2),
	 ('450',3,5,2),
	 ('20',4,13,1),
	 ('80',4,14,1),
	 ('200',4,15,2),
	 ('10',4,16,2);
INSERT INTO shakeitapp_tcocktailingredients (ci_quantity,ci_cocktail_id,ci_ingredient_id,ci_unit_id) VALUES
	 ('20',5,17,1),
	 ('15',5,6,1),
	 ('150',5,18,1),
	 ('220',5,19,2),
	 ('1',5,20,3),
	 ('50',5,21,2),
	 ('20',6,22,1),
	 ('15',6,6,1),
	 ('120',6,7,1),
	 ('3',6,23,3);
INSERT INTO shakeitapp_tcocktailingredients (ci_quantity,ci_cocktail_id,ci_ingredient_id,ci_unit_id) VALUES
	 ('180',6,5,2);
