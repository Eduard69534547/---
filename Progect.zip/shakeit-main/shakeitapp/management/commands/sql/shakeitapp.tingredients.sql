INSERT INTO shakeitapp_tingredients (ingredient_name,ingredient_name_translit,ingredient_url,ingredient_group_id) VALUES
	 ('Сахарный сироп','Saxarny`j sirop','saxarnyj-sirop',7),
	 ('Содовая','Sodovaya','sodovaya',9),
	 ('Лимон','Limon','limon',11),
	 ('Мята листья','Myata list`ya','myata-listya',12),
	 ('Лед в кубиках','Led v kubikax','led-v-kubikax',12),
	 ('Лимонный сок','Limonny`j sok','limonnyj-sok',8),
	 ('Спрайт','Sprajt','sprajt',9),
	 ('Арбуз','Arbuz','arbuz',11),
	 ('Кокосовый сироп','Kokosovy`j sirop','kokosovyj-sirop',7),
	 ('Ананасовый сок','Ananasovy`j sok','ananasovyj-sok',8);
INSERT INTO shakeitapp_tingredients (ingredient_name,ingredient_name_translit,ingredient_url,ingredient_group_id) VALUES
	 ('Банан','Banan','banan',11),
	 ('Красный виноград','Krasny`j vinograd','krasnyj-vinograd',11),
	 ('Шоколадный сироп','Shokoladny`j sirop','shokoladnyj-sirop',7),
	 ('Молоко','Moloko','moloko',9),
	 ('Шоколадное мороженное','Shokoladnoe morozhennoe','shokoladnoe-morozhennoe',12),
	 ('Черный шоколад','Czerny`j shokolad','czernyj-shokolad',12),
	 ('Гренадин','Grenadin','grenadin',7),
	 ('Персиковый сок','Persikovy`j sok','persikovyj-sok',8),
	 ('Яблоко','Yabloko','yabloko',11),
	 ('Коктейльная вишня красная','Koktejl`naya vishnya krasnaya','koktejlnaya-vishnya-krasnaya',12);
INSERT INTO shakeitapp_tingredients (ingredient_name,ingredient_name_translit,ingredient_url,ingredient_group_id) VALUES
	 ('Дробленый лед','Drobleny`j led','droblenyj-led',12),
	 ('Сироп розы','Sirop rozy`','sirop-rozy',7),
	 ('Лепестки роз','Lepestki roz','lepestki-roz',12);
