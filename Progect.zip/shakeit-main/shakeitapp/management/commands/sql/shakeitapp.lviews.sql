INSERT INTO shakeitapp_lviews (lv_date,lv_quantity,lv_cocktail_id) VALUES
	 ('{{ date }}',1,1),
	 ('{{ date }}',1,2),
	 ('{{ date }}',1,3),
	 ('{{ date }}',1,4),
	 ('{{ date }}',1,5),
	 ('{{ date }}',1,6);
