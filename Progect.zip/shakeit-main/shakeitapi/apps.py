from django.apps import AppConfig


class ShakeitapiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'shakeitapi'
    verbose_name = 'API сайта ShakeIt.su'
